'''x=int(input("please enter  first number "))
y=int(input("please enter scound number "))
print (x+y)
--------
num=4
print (num)
num*=2
print (num) 
num1=num+2
print (num1) 
num1+=3
print (num1)
---------
x=2
y=3
print (x/3)
print (x//y)'''




